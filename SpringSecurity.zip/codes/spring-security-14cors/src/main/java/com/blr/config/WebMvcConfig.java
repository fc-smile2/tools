package com.blr.config;

//自定义 mvc 配置类
//@Configuration
//public class WebMvcConfig implements WebMvcConfigurer {
//
//
//    //用来全局处理跨域
//    @Override
//    public void addCorsMappings(CorsRegistry registry) {
//        registry.addMapping("/**") //对那些请求进行跨域处理
//                .allowCredentials(false)
//                .allowedHeaders("*")
//                .allowedMethods("*")
//                .allowedOrigins("*")
//                .maxAge(3600);
//
//    }
//}
