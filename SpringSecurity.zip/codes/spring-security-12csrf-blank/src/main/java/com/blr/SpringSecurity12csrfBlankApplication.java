package com.blr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurity12csrfBlankApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringSecurity12csrfBlankApplication.class, args);
    }

}
