package com.blr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecutiry18oauthClientGithubApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringSecutiry18oauthClientGithubApplication.class, args);
    }

}
