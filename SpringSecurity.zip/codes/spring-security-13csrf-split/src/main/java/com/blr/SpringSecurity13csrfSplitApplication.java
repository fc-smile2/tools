package com.blr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurity13csrfSplitApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringSecurity13csrfSplitApplication.class, args);
    }

}
