package com.blr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurity19authorizationServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
