package com.blr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurity17dynamicAuthorizeApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringSecurity17dynamicAuthorizeApplication.class, args);
    }

}
