package com.blr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurity13csrfWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringSecurity13csrfWebApplication.class, args);
    }

}
