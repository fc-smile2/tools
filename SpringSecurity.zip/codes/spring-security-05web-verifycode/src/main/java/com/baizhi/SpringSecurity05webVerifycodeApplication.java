package com.baizhi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurity05webVerifycodeApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringSecurity05webVerifycodeApplication.class, args);
    }

}
