package com.blr.springsecurity09remembermeweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurity09rememberMeWebApplicationTests {

    @Test
    void contextLoads() {
    }

}
