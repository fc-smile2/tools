package com.blr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurity20resourceServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringSecurity20resourceServerApplication.class, args);
    }

}
